﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double LadoA, LadoB, LadoC;
            bool FuncionaPorra = true;
            if (!Double.TryParse(txtLadoA.Text, out LadoA) || !Double.TryParse(txtLadoB.Text, out LadoB) || !Double.TryParse(txtLadoC.Text, out LadoC))
            {
                MessageBox.Show("Erro, conserte.");
            }
            else if (FuncionaPorra == true)
            {
                LadoA = Convert.ToDouble(txtLadoA.Text);
                LadoB = Convert.ToDouble(txtLadoB.Text);
                LadoC = Convert.ToDouble(txtLadoC.Text);
                if ((LadoA < LadoB + LadoC) && (LadoA > Math.Abs(LadoB - LadoC)) &&
                (LadoB < LadoA + LadoC) && (LadoB > Math.Abs(LadoA - LadoC)) &&
                (LadoC < LadoA + LadoB) && (LadoC > Math.Abs(LadoA - LadoB)))
                {
                    if ((LadoA == LadoB) && (LadoB == LadoC))
                    {
                        MessageBox.Show("O triângulo é equilátero.");
                    }
                    else if ((LadoA == LadoB) || (LadoB == LadoC) || (LadoA == LadoC))
                    {
                        MessageBox.Show("O triângulo é isósceles.");
                    }
                    else
                    {
                        MessageBox.Show("O triângulo é escaleno.");
                    }
                }
                else
                    MessageBox.Show("Valores inválidos, não formam triângulo");
            }
            
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
        }
    }
}
