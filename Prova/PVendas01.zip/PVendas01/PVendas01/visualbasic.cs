﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PVendas01
{
    public partial class visualbasic : Component
    {
        public visualbasic()
        {
            InitializeComponent();
        }

        public visualbasic(IContainer container)
        {
            container.Add(this);

            InitializeComponent();
        }
    }
}
